/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'cs', {
	alt: 'Alternativní text',
	btnUpload: 'Odeslat na server',
	captioned: 'Obrázek s popisem',
	captionPlaceholder: 'Popis',
	infoTab: 'Informace o obrázku',
	lockRatio: 'Zámek',
	menu: 'Vlastnosti obrázku',
	pathName: 'Obrázek',
	pathNameCaption: 'Popis',
	resetSize: 'Původní velikost',
	resizer: 'Klepněte a táhněte pro změnu velikosti',
	title: 'Vlastnosti obrázku',
	uploadTab: 'Odeslat',
	urlMissing: 'Zadané URL zdroje obrázku nebylo nalezeno.',
	altMissing: 'Alternative text is missing.' // MISSING
} );
